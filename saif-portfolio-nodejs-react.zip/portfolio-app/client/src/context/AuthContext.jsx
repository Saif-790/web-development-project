import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api } from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [username, setUsername] = useState(null);
  const [checking, setChecking] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const data = await api.me();
      setUsername(data.username);
    } catch (e) {
      setUsername(null);
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const login = async (u, p) => {
    const data = await api.login(u, p);
    setUsername(data.username);
    return data;
  };

  const logout = async () => {
    await api.logout();
    setUsername(null);
  };

  return (
    <AuthContext.Provider value={{ username, isAuthenticated: !!username, checking, login, logout, refresh }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
