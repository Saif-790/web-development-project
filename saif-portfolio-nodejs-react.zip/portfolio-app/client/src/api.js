const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

/**
 * Thin fetch wrapper.
 * `credentials: 'include'` is essential — it's what lets the browser
 * send/receive the httpOnly auth cookie. We never touch the token
 * from JS, which is the whole point (protects it from XSS).
 */
async function request(path, options = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    // no JSON body
  }

  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

export const api = {
  // auth
  login: (username, password) =>
    request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  logout: () => request('/auth/logout', { method: 'POST' }),
  me: () => request('/auth/me'),

  // public projects
  getProjects: () => request('/projects'),

  // admin projects
  getAllProjectsAdmin: () => request('/projects/admin/all'),
  createProject: (data) => request('/projects', { method: 'POST', body: JSON.stringify(data) }),
  updateProject: (id, data) => request(`/projects/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProject: (id) => request(`/projects/${id}`, { method: 'DELETE' }),

  // messages
  sendMessage: (data) => request('/messages', { method: 'POST', body: JSON.stringify(data) }),
  getMessages: () => request('/messages'),
  markMessageRead: (id) => request(`/messages/${id}/read`, { method: 'PATCH' }),
  deleteMessage: (id) => request(`/messages/${id}`, { method: 'DELETE' })
};
