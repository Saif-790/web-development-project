import Navbar from '../components/Navbar.jsx';
import Footer from '../components/Footer.jsx';
import BackToTop from '../components/BackToTop.jsx';
import Hero from '../components/sections/Hero.jsx';
import About from '../components/sections/About.jsx';
import Stats from '../components/sections/Stats.jsx';
import Work from '../components/sections/Work.jsx';
import Services from '../components/sections/Services.jsx';
import { TechStack, WhyWordPress } from '../components/sections/TechAndWhy.jsx';
import { Experience, Process } from '../components/sections/ExperienceAndProcess.jsx';
import { Showcase, Statement } from '../components/sections/ShowcaseAndStatement.jsx';
import Contact from '../components/sections/Contact.jsx';

export default function Home() {
  return (
    <>
      <Navbar />
      <main id="top">
        <Hero />
        <About />
        <Stats />
        <Work />
        <Services />
        <TechStack />
        <WhyWordPress />
        <Experience />
        <Process />
        <Showcase />
        <Statement />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
    </>
  );
}
