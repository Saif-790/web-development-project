import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../api';

const EMPTY_PROJECT = {
  title: '', category: 'business', year: '2026', image: '', description: '',
  technologies: [], url: '', status: 'published'
};

function ProjectModal({ initial, onClose, onSave }) {
  const [form, setForm] = useState(initial || EMPTY_PROJECT);
  const [techInput, setTechInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const addTech = (e) => {
    if (e.key === 'Enter' && techInput.trim()) {
      e.preventDefault();
      set('technologies', [...(form.technologies || []), techInput.trim()]);
      setTechInput('');
    }
  };
  const removeTech = (t) => set('technologies', form.technologies.filter((x) => x !== t));

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await onSave(form);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay open" style={{ display: 'flex' }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box modal-lg" role="dialog" aria-modal="true">
        <div className="modal-head">
          <h3>{form.id ? 'Edit Project' : 'Add New Project'}</h3>
          <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <form onSubmit={submit}>
          <div className="form-row">
            <label>PROJECT TITLE</label>
            <input value={form.title} onChange={(e) => set('title', e.target.value)} required placeholder="e.g. Modern Business Website" />
          </div>
          <div className="form-grid-2">
            <div className="form-row">
              <label>PROJECT CATEGORY</label>
              <select value={form.category} onChange={(e) => set('category', e.target.value)}>
                <option value="business">Business</option>
                <option value="ecommerce">Ecommerce / WooCommerce</option>
                <option value="agency">Agency</option>
                <option value="landing-page">Landing Page</option>
                <option value="portfolio">Personal Brand / Portfolio</option>
              </select>
            </div>
            <div className="form-row">
              <label>PROJECT YEAR</label>
              <input type="number" min="2015" max="2100" value={form.year} onChange={(e) => set('year', e.target.value)} required />
            </div>
          </div>
          <div className="form-row">
            <label>IMAGE URL</label>
            <input value={form.image} onChange={(e) => set('image', e.target.value)} placeholder="https://images.example.com/photo.jpg" />
          </div>
          <div className="form-row">
            <label>PROJECT DESCRIPTION</label>
            <textarea value={form.description} onChange={(e) => set('description', e.target.value)} required placeholder="Short description of the project" />
          </div>
          <div className="form-row">
            <label>TECHNOLOGIES USED</label>
            <div className="tag-input-wrap">
              {(form.technologies || []).map((t) => (
                <span className="tag" key={t} onClick={() => removeTech(t)} style={{ cursor: 'pointer' }} title="Click to remove">{t} ✕</span>
              ))}
              <input value={techInput} onChange={(e) => setTechInput(e.target.value)} onKeyDown={addTech} placeholder="Type a technology and press Enter" />
            </div>
          </div>
          <div className="form-grid-2">
            <div className="form-row">
              <label>PROJECT URL</label>
              <input type="url" value={form.url} onChange={(e) => set('url', e.target.value)} placeholder="https://example.com" />
            </div>
            <div className="form-row">
              <label>PROJECT STATUS</label>
              <select value={form.status} onChange={(e) => set('status', e.target.value)}>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
            </div>
          </div>
          {error && <p style={{ color: '#ff6b6b', fontSize: 13 }}>{error}</p>}
          <div className="modal-actions">
            <button type="button" className="btn btn-ghost btn-sm" onClick={onClose}>CANCEL</button>
            <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>{saving ? 'SAVING…' : 'SAVE PROJECT'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function DashboardView({ projects, messages }) {
  const published = projects.filter((p) => p.status === 'published').length;
  const drafts = projects.filter((p) => p.status === 'draft').length;
  return (
    <>
      <div className="admin-topbar">
        <div><h2>Dashboard</h2><div className="muted-line">Overview of your portfolio content.</div></div>
      </div>
      <div className="admin-stats-grid">
        <div className="admin-stat-card"><div className="num">{projects.length}</div><div className="lbl">TOTAL PROJECTS</div></div>
        <div className="admin-stat-card"><div className="num">{published}</div><div className="lbl">PUBLISHED</div></div>
        <div className="admin-stat-card"><div className="num">{drafts}</div><div className="lbl">DRAFTS</div></div>
        <div className="admin-stat-card"><div className="num">{messages.length}</div><div className="lbl">MESSAGES</div></div>
      </div>
      <div className="admin-panel">
        <h3>Recent projects</h3>
        {projects.slice(0, 5).map((p) => (
          <div className="admin-recent-row" key={p.id}><span>{p.title}</span><span className={`status-pill ${p.status}`}>{p.status}</span></div>
        ))}
        {projects.length === 0 && <div className="admin-empty">No projects yet.</div>}
      </div>
      <div className="admin-panel">
        <h3>Recent messages</h3>
        {messages.slice(0, 5).map((m) => (
          <div className="admin-recent-row" key={m.id}><span>{m.name} — {m.email}</span><span className="muted">{new Date(m.createdAt).toLocaleDateString()}</span></div>
        ))}
        {messages.length === 0 && <div className="admin-empty">No messages yet.</div>}
      </div>
    </>
  );
}

function ProjectsView({ projects, reload }) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [modalProject, setModalProject] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [pendingDelete, setPendingDelete] = useState(null);

  const filtered = projects.filter((p) => {
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (search && !`${p.title} ${p.category} ${p.year}`.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const openAdd = () => { setModalProject(EMPTY_PROJECT); setShowModal(true); };
  const openEdit = (p) => { setModalProject(p); setShowModal(true); };

  const save = async (data) => {
    if (data.id) await api.updateProject(data.id, data);
    else await api.createProject(data);
    setShowModal(false);
    reload();
  };

  const confirmDelete = async () => {
    await api.deleteProject(pendingDelete);
    setPendingDelete(null);
    reload();
  };

  return (
    <>
      <div className="admin-topbar">
        <div><h2>Projects</h2><div className="muted-line">Manage your portfolio projects.</div></div>
        <button className="btn btn-primary btn-sm" onClick={openAdd}>ADD PROJECT</button>
      </div>
      <div className="admin-toolbar">
        <div className="admin-toolbar-left">
          <input className="admin-search-input" placeholder="Search projects…" value={search} onChange={(e) => setSearch(e.target.value)} />
          <select className="admin-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="all">All statuses</option>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
          </select>
        </div>
      </div>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead><tr><th>Image</th><th>Title</th><th>Category</th><th>Year</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id}>
                <td>{p.image ? <img className="admin-thumb" src={p.image} alt="" /> : '—'}</td>
                <td>{p.title}</td>
                <td>{p.category}</td>
                <td>{p.year}</td>
                <td><span className={`status-pill ${p.status}`}>{p.status}</span></td>
                <td>
                  <div className="row-actions">
                    <button className="icon-action" onClick={() => openEdit(p)} aria-label="Edit">✎</button>
                    <button className="icon-action delete" onClick={() => setPendingDelete(p.id)} aria-label="Delete">🗑</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="admin-empty">No projects found.</div>}
      </div>

      {showModal && (
        <ProjectModal initial={modalProject} onClose={() => setShowModal(false)} onSave={save} />
      )}

      {pendingDelete && (
        <div className="modal-overlay open" style={{ display: 'flex' }} onClick={(e) => { if (e.target === e.currentTarget) setPendingDelete(null); }}>
          <div className="modal-box" style={{ maxWidth: 400 }} role="dialog" aria-modal="true">
            <div className="modal-head"><h3>Delete project?</h3><button className="modal-close" onClick={() => setPendingDelete(null)}>✕</button></div>
            <p className="muted" style={{ fontSize: 14 }}>Are you sure you want to delete this project? This can't be undone.</p>
            <div className="modal-actions">
              <button className="btn btn-ghost btn-sm" onClick={() => setPendingDelete(null)}>CANCEL</button>
              <button className="btn btn-danger btn-sm" onClick={confirmDelete}>DELETE</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function MessagesView({ messages, reload }) {
  const markRead = async (id) => { await api.markMessageRead(id); reload(); };
  const remove = async (id) => { await api.deleteMessage(id); reload(); };

  return (
    <>
      <div className="admin-topbar"><div><h2>Messages</h2><div className="muted-line">Messages submitted through the contact form.</div></div></div>
      <div className="admin-panel">
        {messages.length === 0 && <div className="admin-empty">No messages yet.</div>}
        {messages.map((m) => (
          <div key={m.id} className="admin-recent-row" style={{ alignItems: 'flex-start', flexDirection: 'column', gap: 6, padding: '16px 0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <strong>{m.name}</strong>
              <span className="muted" style={{ fontSize: 12 }}>{new Date(m.createdAt).toLocaleString()}</span>
            </div>
            <div className="muted" style={{ fontSize: 13 }}>{m.email}</div>
            <p style={{ fontSize: 13.5 }}>{m.message}</p>
            <div className="row-actions">
              {!m.read && <button className="btn btn-ghost btn-sm" onClick={() => markRead(m.id)}>MARK READ</button>}
              <button className="btn btn-danger btn-sm" onClick={() => remove(m.id)}>DELETE</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function SettingsView() {
  const { username, logout } = useAuth();
  return (
    <>
      <div className="admin-topbar"><div><h2>Settings</h2></div></div>
      <div className="admin-panel">
        <h3>Account</h3>
        <p className="muted" style={{ fontSize: 13.5 }}>Signed in as <strong>{username}</strong>.</p>
      </div>
      <div className="admin-panel">
        <h3>Security</h3>
        <p className="muted" style={{ fontSize: 13.5, lineHeight: 1.7 }}>
          This dashboard is protected by a server-side login: the admin password is stored as a bcrypt hash
          (never in plain text), sessions use a signed, httpOnly JWT cookie that JavaScript can't read, and
          login attempts are rate-limited to slow down brute-force guessing. Data is stored on the server,
          not in this browser's local storage.
        </p>
        <button className="btn btn-ghost btn-sm" onClick={logout} style={{ marginTop: 14 }}>LOG OUT</button>
      </div>
    </>
  );
}

export default function AdminDashboard() {
  const [view, setView] = useState('dashboard');
  const [projects, setProjects] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const { logout } = useAuth();

  const reload = () => {
    Promise.all([api.getAllProjectsAdmin(), api.getMessages()])
      .then(([p, m]) => { setProjects(p); setMessages(m); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { reload(); }, []);

  const unread = messages.filter((m) => !m.read).length;

  const NAV = [
    { key: 'dashboard', label: 'DASHBOARD' },
    { key: 'projects', label: 'PROJECTS' },
    { key: 'messages', label: `MESSAGES${unread ? ` (${unread})` : ''}` },
    { key: 'settings', label: 'SETTINGS' }
  ];

  return (
    <div id="admin-app" className="open" style={{ display: 'flex' }}>
      <div className="admin-shell">
        <aside className="admin-sidebar">
          <div className="admin-brand"><span className="brand-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent-light)' }}></span>SAIF<span>.DEV</span></div>
          <nav className="admin-nav">
            {NAV.map((n) => (
              <button key={n.key} className={view === n.key ? 'active' : ''} onClick={() => setView(n.key)}>{n.label}</button>
            ))}
          </nav>
          <div className="admin-sidebar-foot">
            <Link to="/" className="admin-back-site">← Back to site</Link>
            <button className="admin-back-site" onClick={logout} style={{ background: 'none', border: 'none', width: '100%', textAlign: 'left', cursor: 'pointer' }}>Log out</button>
          </div>
        </aside>
        <main className="admin-main">
          {loading ? (
            <p className="muted">Loading dashboard…</p>
          ) : (
            <>
              {view === 'dashboard' && <DashboardView projects={projects} messages={messages} />}
              {view === 'projects' && <ProjectsView projects={projects} reload={reload} />}
              {view === 'messages' && <MessagesView messages={messages} reload={reload} />}
              {view === 'settings' && <SettingsView />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
