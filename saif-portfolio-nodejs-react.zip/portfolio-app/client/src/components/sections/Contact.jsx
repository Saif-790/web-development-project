import { useState } from 'react';
import { api } from '../../api';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('idle'); // idle | sending | sent | error
  const [errorMsg, setErrorMsg] = useState('');

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setStatus('sending');
    setErrorMsg('');
    try {
      await api.sendMessage(form);
      setStatus('sent');
      setForm({ name: '', email: '', message: '' });
    } catch (err) {
      setStatus('error');
      setErrorMsg(err.message);
    }
  };

  return (
    <section className="section section-border-top" id="contact">
      <div className="container">
        <div className="contact-inner reveal in-view">
          <div className="sub">YOUR NEXT WEBSITE STARTS HERE.</div>
          <h2>Let's build something great.</h2>
          <p className="desc">Have a project in mind? Let's turn your idea into a modern, professional and high-performing WordPress website.</p>
          <div className="contact-ctas">
            <a href="mailto:mdsaifislam790@gmail.com" className="btn btn-primary">START A PROJECT</a>
            <a href="mailto:mdsaifislam790@gmail.com" className="btn btn-ghost">EMAIL ME</a>
            <a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp">CHAT ON WHATSAPP</a>
          </div>
          <div className="contact-availability"><span className="status-dot" aria-hidden="true"></span>CURRENTLY AVAILABLE FOR NEW PROJECTS</div>
          <div className="contact-details">
            <div className="contact-detail-item"><div className="contact-detail-label">WHATSAPP</div><div className="contact-detail-value"><a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer">01516549964</a></div></div>
            <div className="contact-detail-item"><div className="contact-detail-label">EMAIL</div><div className="contact-detail-value"><a href="mailto:mdsaifislam790@gmail.com">mdsaifislam790@gmail.com</a></div></div>
          </div>

          <form onSubmit={onSubmit} style={{ maxWidth: 560, marginTop: 40 }}>
            <div className="form-row">
              <label htmlFor="c-name">YOUR NAME</label>
              <input id="c-name" name="name" value={form.name} onChange={onChange} required placeholder="Your name" />
            </div>
            <div className="form-row">
              <label htmlFor="c-email">YOUR EMAIL</label>
              <input id="c-email" name="email" type="email" value={form.email} onChange={onChange} required placeholder="you@example.com" />
            </div>
            <div className="form-row">
              <label htmlFor="c-message">MESSAGE</label>
              <textarea id="c-message" name="message" value={form.message} onChange={onChange} required placeholder="Tell me about your project" />
            </div>
            <button type="submit" className="btn btn-primary btn-sm" disabled={status === 'sending'}>
              {status === 'sending' ? 'SENDING…' : 'SEND MESSAGE'}
            </button>
            {status === 'sent' && <p className="muted" style={{ marginTop: 12 }}>Thanks — your message has been sent!</p>}
            {status === 'error' && <p style={{ marginTop: 12, color: '#ff6b6b' }}>{errorMsg}</p>}
          </form>

          <div className="social-row" style={{ marginTop: 34 }}>
            <a href="#" target="_blank" rel="noopener noreferrer">Instagram</a>
            <a href="#" target="_blank" rel="noopener noreferrer">Facebook</a>
            <a href="#" target="_blank" rel="noopener noreferrer">LinkedIn</a>
            <a href="#" target="_blank" rel="noopener noreferrer">Behance</a>
            <a href="#" target="_blank" rel="noopener noreferrer">GitHub</a>
            <a href="#" target="_blank" rel="noopener noreferrer">YouTube</a>
          </div>
        </div>
      </div>
    </section>
  );
}
