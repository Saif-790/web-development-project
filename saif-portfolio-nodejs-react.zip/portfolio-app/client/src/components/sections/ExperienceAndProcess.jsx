const TIMELINE = [
  { year: '2026', title: 'WordPress Web Developer', org: 'FREELANCE / REMOTE', text: 'Designing and developing modern WordPress websites for businesses, brands and entrepreneurs.', tags: ['WordPress', 'Elementor', 'WooCommerce'] },
  { year: '2025', title: 'WordPress & Elementor Specialist', org: 'FREELANCE', text: 'Built responsive websites, landing pages and eCommerce solutions using WordPress and Elementor.', tags: ['WordPress', 'Elementor', 'Responsive Design'] },
  { year: '2024', title: 'Web Designer & Developer', org: 'FREELANCE', text: 'Worked on website design, development, responsive layouts and performance optimization.', tags: ['HTML', 'CSS', 'Performance'] }
];

const PROCESS = [
  { num: '01', title: 'DISCOVERY', text: 'Understand the business, audience and project goals.' },
  { num: '02', title: 'PLANNING', text: 'Create the structure, content hierarchy and technical roadmap.' },
  { num: '03', title: 'DESIGN', text: 'Build a clean, modern and conversion-focused visual direction.' },
  { num: '04', title: 'DEVELOPMENT', text: 'Develop the website using WordPress and modern web technologies.' },
  { num: '05', title: 'LAUNCH', text: 'Test, optimize and launch a fast, responsive and reliable website.' }
];

export function Experience() {
  return (
    <section className="section section-border-top" id="experience">
      <div className="container">
        <div className="section-head reveal in-view"><div><div className="kicker">EXPERIENCE</div><h2>Where I've worked</h2></div></div>
        <div className="timeline reveal in-view">
          {TIMELINE.map((t) => (
            <div className="timeline-item" key={t.year + t.title}>
              <span className="timeline-dot" aria-hidden="true"></span>
              <div className="timeline-year">{t.year}</div>
              <h3>{t.title}</h3>
              <div className="timeline-org">{t.org}</div>
              <p>{t.text}</p>
              <div className="timeline-tags">{t.tags.map((tag) => <span className="tag" key={tag}>{tag}</span>)}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Process() {
  return (
    <section className="section section-border-top" style={{ paddingBottom: 0 }}>
      <div className="container"><div className="section-head reveal in-view"><div><div className="kicker">MY PROCESS</div><h2>How a project comes together</h2></div></div></div>
      <div className="process-row reveal reveal-stagger in-view">
        {PROCESS.map((p, i) => (
          <div className="process-step" style={{ '--i': i }} key={p.num}>
            <span className="process-num">{p.num}</span><h3>{p.title}</h3><p>{p.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
