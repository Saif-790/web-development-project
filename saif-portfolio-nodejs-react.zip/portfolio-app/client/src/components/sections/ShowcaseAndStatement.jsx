export function Showcase() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-head reveal in-view"><div><div className="kicker">BUILT FOR THE WEB</div><h2>Made to look right, everywhere</h2></div></div>
        <div className="showcase-wrap reveal in-view">
          <div className="browser-mock">
            <div className="browser-bar"><div className="browser-dots"><span></span><span></span><span></span></div><div className="browser-url">yourwebsite.com</div></div>
            <div className="browser-body">
              <span className="preview-tag">WEBSITE PREVIEW</span>
              <h3>Clean layout. Fast load. Built to convert.</h3>
              <div className="browser-skel"><div></div><div></div><div></div></div>
            </div>
          </div>
          <div className="showcase-feats">
            <div className="feat-pill"><i></i>RESPONSIVE</div><div className="feat-pill"><i></i>FAST</div>
            <div className="feat-pill"><i></i>SEO READY</div><div className="feat-pill"><i></i>MOBILE FRIENDLY</div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Statement() {
  return (
    <section className="section">
      <div className="container statement reveal in-view">
        <h2>Good design gets attention.<br /><em>Great development makes it work.</em></h2>
        <p>The best websites bring design, development, performance and usability together — a site that looks professional, loads fast and gives visitors a reason to stay.</p>
      </div>
    </section>
  );
}
