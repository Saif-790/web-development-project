const SERVICES = [
  { num: '01', title: 'WordPress Development', text: 'Professional WordPress websites built with clean structure, responsive layouts and scalable functionality.' },
  { num: '02', title: 'Elementor Development', text: 'Pixel-perfect Elementor websites with custom layouts, responsive design and advanced styling.' },
  { num: '03', title: 'WooCommerce Development', text: 'Modern eCommerce stores with optimized product layouts and conversion-focused shopping experiences.' },
  { num: '04', title: 'Custom Website Design', text: 'Unique website designs tailored to your brand, audience and business goals.' },
  { num: '05', title: 'Landing Page Design', text: 'High-converting landing pages designed to communicate your offer and drive action.' },
  { num: '06', title: 'Website Speed Optimization', text: 'Performance-focused optimization to improve loading speed and overall user experience.' },
  { num: '07', title: 'Responsive Web Design', text: 'Websites that look and work beautifully across desktop, tablet and mobile devices.' },
  { num: '08', title: 'Website Maintenance', text: 'Reliable WordPress updates, content changes, bug fixes and ongoing website support.' }
];

export default function Services() {
  return (
    <section className="section section-border-top" id="services">
      <div className="container">
        <div className="section-head reveal in-view">
          <div><div className="kicker">WHAT I DO</div><h2>Services</h2></div>
          <p className="lede">From design to development, I build WordPress websites that are made to perform.</p>
        </div>
        <div className="services-grid reveal in-view">
          {SERVICES.map((s) => (
            <div className="service-card" key={s.num}>
              <span className="service-num">{s.num}</span>
              <div><h3>{s.title}</h3><p>{s.text}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
