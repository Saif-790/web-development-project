import { useEffect, useState } from 'react';
import { api } from '../../api';

const FILTERS = [
  { key: 'all', label: 'ALL' },
  { key: 'wordpress', label: 'WORDPRESS' },
  { key: 'elementor', label: 'ELEMENTOR' },
  { key: 'woocommerce', label: 'WOOCOMMERCE' },
  { key: 'business', label: 'BUSINESS' },
  { key: 'landing-page', label: 'LANDING PAGE' },
  { key: 'ecommerce', label: 'ECOMMERCE' },
  { key: 'portfolio', label: 'PORTFOLIO' }
];

function categoryFilterTags(project) {
  const tags = ['wordpress', project.category];
  const t = (project.technologies || []).map((x) => x.toLowerCase());
  if (t.includes('elementor')) tags.push('elementor');
  if (t.includes('woocommerce')) tags.push('woocommerce');
  if (project.category === 'ecommerce') tags.push('woocommerce');
  return tags;
}

export default function Work() {
  const [projects, setProjects] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.getProjects()
      .then(setProjects)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const visible = filter === 'all'
    ? projects
    : projects.filter((p) => categoryFilterTags(p).includes(filter));

  return (
    <section className="section section-border-top" id="work">
      <div className="container">
        <div className="section-head reveal in-view">
          <div><div className="kicker">SELECTED WORK</div><h2>Recent projects</h2></div>
          <p className="lede">A selection of websites I've designed and developed for businesses, brands and creators.</p>
        </div>

        <div className="filter-bar reveal in-view" role="tablist" aria-label="Filter projects by category">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              className={`filter-btn${filter === f.key ? ' active' : ''}`}
              role="tab"
              aria-selected={filter === f.key}
              onClick={() => setFilter(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="work-list">
          {loading && <p className="muted">Loading projects…</p>}
          {error && <p className="muted">Couldn't load projects: {error}</p>}
          {!loading && !error && visible.length === 0 && (
            <div className="admin-empty">No projects match this filter yet.</div>
          )}
          {!loading && visible.map((p) => (
            <article className="work-card" key={p.id}>
              {p.image && <img src={p.image} alt={p.title} loading="lazy" />}
              <div>
                <h3>{p.title}</h3>
                <p className="muted">{p.description}</p>
                <div className="timeline-tags">
                  {(p.technologies || []).map((t) => <span className="tag" key={t}>{t}</span>)}
                </div>
                {p.url && (
                  <a className="link-arrow" href={p.url} target="_blank" rel="noopener noreferrer" style={{ marginTop: 14, display: 'inline-flex' }}>
                    VISIT SITE
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
