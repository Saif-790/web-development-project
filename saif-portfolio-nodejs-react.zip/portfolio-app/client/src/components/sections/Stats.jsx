import { useEffect, useRef, useState } from 'react';

const STATS = [
  { target: 5, suffix: '+', label: 'YEARS EXPERIENCE' },
  { target: 100, suffix: '+', label: 'WEBSITES BUILT' },
  { target: 50, suffix: '+', label: 'HAPPY CLIENTS' },
  { target: 10, suffix: 'M+', label: 'TOTAL WEBSITE VISITS' }
];

function Counter({ target, suffix }) {
  const ref = useRef(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) { setValue(target); return; }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const duration = 1400;
          let start = null;
          const step = (ts) => {
            if (!start) start = ts;
            const progress = Math.min((ts - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setValue(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(step); else setValue(target);
          };
          requestAnimationFrame(step);
          observer.unobserve(el);
        }
      });
    }, { threshold: 0.6 });

    observer.observe(el);
    return () => observer.disconnect();
  }, [target]);

  return (
    <div className="stat-number" ref={ref}>
      <span>{value}</span><span className="accent-text">{suffix}</span>
    </div>
  );
}

export default function Stats() {
  return (
    <section className="section section-border-top" style={{ paddingTop: 0 }}>
      <div className="container">
        <div className="stats-strip reveal in-view">
          {STATS.map((s) => (
            <div className="stat-item" key={s.label}>
              <Counter target={s.target} suffix={s.suffix} />
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
