import { useEffect, useRef, useState } from 'react';

export default function Hero() {
  const heroRef = useRef(null);
  const cardRef = useRef(null);
  const gridRef = useRef(null);
  const canvasRef = useRef(null);
  const [meterWidth, setMeterWidth] = useState('0%');

  const prefersReducedMotion = typeof window !== 'undefined' &&
    window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => {
    const t = setTimeout(() => setMeterWidth('98%'), 700);
    return () => clearTimeout(t);
  }, []);

  // mouse parallax
  useEffect(() => {
    const heroEl = heroRef.current;
    if (!heroEl || prefersReducedMotion) return;
    let targetX = 0, targetY = 0, curX = 0, curY = 0, raf;

    const onMove = (e) => {
      const rect = heroEl.getBoundingClientRect();
      targetX = (e.clientX - rect.left) / rect.width - 0.5;
      targetY = (e.clientY - rect.top) / rect.height - 0.5;
    };
    const loop = () => {
      curX += (targetX - curX) * 0.06;
      curY += (targetY - curY) * 0.06;
      if (cardRef.current) cardRef.current.style.transform = `translate(${curX * 22}px, ${curY * 18}px)`;
      if (gridRef.current) gridRef.current.style.transform = `translate(${curX * -12}px, ${curY * -10}px)`;
      raf = requestAnimationFrame(loop);
    };
    heroEl.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(loop);
    return () => { heroEl.removeEventListener('mousemove', onMove); cancelAnimationFrame(raf); };
  }, [prefersReducedMotion]);

  // floating particles canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const heroEl = heroRef.current;
    if (!canvas || !heroEl || prefersReducedMotion) return;
    const ctx = canvas.getContext('2d');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let particles = [];
    let raf;

    const count = window.innerWidth < 768 ? 26 : 50;

    const resize = () => {
      const rect = heroEl.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const create = () => {
      const rect = heroEl.getBoundingClientRect();
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * rect.width, y: Math.random() * rect.height,
        r: Math.random() * 1.6 + 0.4, vx: (Math.random() - 0.5) * 0.15, vy: (Math.random() - 0.5) * 0.15,
        o: Math.random() * 0.5 + 0.15
      }));
    };
    const draw = () => {
      const rect = heroEl.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);
      particles.forEach((p) => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = rect.width; if (p.x > rect.width) p.x = 0;
        if (p.y < 0) p.y = rect.height; if (p.y > rect.height) p.y = 0;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(56,189,248,${p.o})`; ctx.fill();
      });
      raf = requestAnimationFrame(draw);
    };

    resize(); create(); raf = requestAnimationFrame(draw);
    let resizeTimeout;
    const onResize = () => { clearTimeout(resizeTimeout); resizeTimeout = setTimeout(() => { resize(); create(); }, 200); };
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('resize', onResize); cancelAnimationFrame(raf); };
  }, [prefersReducedMotion]);

  return (
    <section className="hero" id="hero" ref={heroRef}>
      <div className="bg-fx">
        <canvas id="particle-canvas" ref={canvasRef} aria-hidden="true"></canvas>
        <div className="bg-grid" id="hero-grid" ref={gridRef} aria-hidden="true"></div>
        <div className="bg-glow" aria-hidden="true"></div>
        <div className="bg-glow two" aria-hidden="true"></div>
      </div>
      <div className="container hero-inner">
        <div className="hero-copy">
          <div className="hero-eyebrow">WORDPRESS DEVELOPER • WEB DESIGNER</div>
          <h1>MD. SAIF ISLAM</h1>
          <div className="hero-title">WORDPRESS WEB DEVELOPER</div>
          <p className="hero-headline">I build fast, modern and conversion-focused WordPress websites.</p>
          <p className="hero-para">I create professional WordPress websites that combine clean design, responsive development, performance, and a seamless user experience.</p>
          <div className="hero-ctas">
            <a href="#work" className="btn btn-primary">EXPLORE MY WORK</a>
            <a href="#contact" className="btn btn-ghost">START A PROJECT</a>
          </div>
          <a href="#services" className="link-arrow hero-secondary-link">
            VIEW SERVICES
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </a>
          <div className="hero-contact-row">
            <a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer" className="contact-chip" aria-label="Chat on WhatsApp">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-10 4.5-10 10 0 1.77.46 3.5 1.34 5.02L2 22l5.13-1.35A9.96 9.96 0 0 0 12.04 22c5.5 0 10-4.5 10-10s-4.5-10-10-10Zm0 18.15c-1.6 0-3.16-.43-4.52-1.24l-.32-.19-3.05.8.81-2.98-.21-.31A8.15 8.15 0 0 1 3.85 12c0-4.5 3.68-8.15 8.19-8.15 4.5 0 8.15 3.66 8.15 8.15 0 4.5-3.65 8.15-8.15 8.15Z" /></svg>
              01516549964
            </a>
            <a href="mailto:mdsaifislam790@gmail.com" className="contact-chip" aria-label="Email Saif">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M3 6h18v12H3z" stroke="currentColor" strokeWidth="1.4" /><path d="m3 7 9 6 9-6" stroke="currentColor" strokeWidth="1.4" /></svg>
              mdsaifislam790@gmail.com
            </a>
          </div>
        </div>

        <div className="hero-visual" ref={cardRef}>
          <div className="dev-card">
            <div className="dev-card-head">
              <div className="dev-card-dots"><span></span><span></span><span></span></div>
              <div className="dev-card-label">STACK.OVERVIEW</div>
            </div>
            <div className="dev-stack">
              {['WORDPRESS', 'ELEMENTOR', 'WOOCOMMERCE', 'PHP', 'HTML', 'CSS', 'JAVASCRIPT', 'MYSQL'].map((s) => (
                <div className="dev-stack-item" key={s}><i></i>{s}</div>
              ))}
            </div>
            <div className="dev-card-meter">
              <div className="dev-meter-row"><span>PERFORMANCE SCORE</span><span className="accent-text">98%</span></div>
              <div className="dev-meter-track"><div className="dev-meter-fill" style={{ width: meterWidth }}></div></div>
            </div>
          </div>
          <div className="float-chip chip-a"><i></i>98% PERFORMANCE</div>
          <div className="float-chip chip-b"><i></i>RESPONSIVE</div>
          <div className="float-chip chip-c"><i></i>SEO READY</div>
          <div className="float-chip chip-d"><i></i>MOBILE FRIENDLY</div>
        </div>
      </div>
    </section>
  );
}
