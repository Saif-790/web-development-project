const CORE = ['WordPress', 'Elementor', 'WooCommerce', 'HTML5', 'CSS3', 'JavaScript'];
const OTHER = ['PHP', 'MySQL', 'Git', 'Figma', 'Photoshop', 'Illustrator', 'Responsive Design', 'SEO', 'Website Optimization', 'Custom CSS', 'UI/UX Design'];

const WHY = [
  { title: 'Fast Development', text: 'Build and launch professional websites efficiently without compromising quality.', icon: <path d="M9 1v4M9 13v4M1 9h4M13 9h4M3.5 3.5l2.8 2.8M11.7 11.7l2.8 2.8M14.5 3.5l-2.8 2.8M6.3 11.7l-2.8 2.8" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /> },
  { title: 'Easy Management', text: 'Websites that clients can easily manage and update themselves.', icon: <><rect x="2" y="2" width="14" height="14" rx="3" stroke="currentColor" strokeWidth="1.3" /><path d="M6 9h6M9 6v6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /></> },
  { title: 'Scalable', text: 'Flexible solutions that can grow with your business.', icon: <path d="M2 15V9M7 15V5M12 15V11M17 15V2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /> },
  { title: 'Business Ready', text: 'Designed around usability, performance and real business goals.', icon: <path d="M9 2l7 3v4c0 4.5-3 7.5-7 8-4-0.5-7-3.5-7-8V5l7-3z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" /> }
];

export function TechStack() {
  return (
    <section className="section section-border-top">
      <div className="container">
        <div className="section-head reveal in-view"><div><div className="kicker">TECH STACK</div><h2>Tools &amp; technologies</h2></div></div>
        <div className="stack-cloud reveal in-view">
          {CORE.map((c) => <span className="stack-chip core" key={c}>{c}</span>)}
          {OTHER.map((c) => <span className="stack-chip" key={c}>{c}</span>)}
        </div>
      </div>
    </section>
  );
}

export function WhyWordPress() {
  return (
    <section className="section section-border-top">
      <div className="container">
        <div className="section-head reveal in-view"><div><div className="kicker">WHY WORDPRESS?</div><h2>Built on a platform that scales</h2></div></div>
        <div className="why-grid reveal reveal-stagger in-view">
          {WHY.map((w, i) => (
            <div className="why-card" style={{ '--i': i }} key={w.title}>
              <div className="why-icon" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none">{w.icon}</svg></div>
              <h3>{w.title}</h3><p>{w.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
