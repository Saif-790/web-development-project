export default function About() {
  return (
    <section className="section section-border-top" id="about">
      <div className="container">
        <div className="kicker">ABOUT ME</div>
        <div className="about-grid">
          <div className="about-text reveal in-view">
            <p className="lede">I'm a WordPress Web Developer focused on creating modern, responsive and high-performing websites for businesses, brands and individuals.</p>
            <p>I transform ideas into professional websites using WordPress, Elementor, WooCommerce and modern web technologies. My approach combines clean design, usability, performance and business-focused functionality.</p>
            <p>From landing pages and business websites to eCommerce stores and custom WordPress solutions, I build websites that look professional, work smoothly and help businesses grow.</p>
          </div>
          <div className="profile-card reveal in-view">
            <div className="profile-row"><span className="profile-label">NAME</span><span className="profile-value">MD. SAIF ISLAM</span></div>
            <div className="profile-row"><span className="profile-label">ROLE</span><span className="profile-value">WORDPRESS WEB DEVELOPER</span></div>
            <div className="profile-row"><span className="profile-label">SPECIALTY</span><span className="profile-value">WORDPRESS • ELEMENTOR • WOOCOMMERCE</span></div>
            <div className="profile-row"><span className="profile-label">WHATSAPP</span><span className="profile-value"><a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer">01516549964</a></span></div>
            <div className="profile-row"><span className="profile-label">EMAIL</span><span className="profile-value"><a href="mailto:mdsaifislam790@gmail.com">mdsaifislam790@gmail.com</a></span></div>
            <div className="profile-row"><span className="profile-label">STATUS</span><span className="profile-value status"><i></i>AVAILABLE FOR WORK</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}
