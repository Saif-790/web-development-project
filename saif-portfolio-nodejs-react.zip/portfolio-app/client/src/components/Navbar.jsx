import { useEffect, useState } from 'react';

const LINKS = [
  { href: '#work', label: 'WORK' },
  { href: '#about', label: 'ABOUT' },
  { href: '#services', label: 'SERVICES' },
  { href: '#experience', label: 'EXPERIENCE' },
  { href: '#contact', label: 'CONTACT' }
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <header className={`nav${scrolled ? ' scrolled' : ''}`} id="site-nav">
        <div className="container nav-inner">
          <a href="#top" className="brand" aria-label="SAIF.DEV — home">
            <span className="brand-dot" aria-hidden="true"></span>
            SAIF<span>.DEV</span>
          </a>
          <nav className="nav-links" aria-label="Primary">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} data-nav>{l.label}</a>
            ))}
          </nav>
          <div className="nav-right">
            <div className="availability"><span className="status-dot" aria-hidden="true"></span>AVAILABLE FOR WORK</div>
            <a href="#contact" className="btn btn-primary nav-cta">LET'S TALK</a>
            <button
              className={`hamburger${menuOpen ? ' open' : ''}`}
              aria-label="Open menu"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((v) => !v)}
            >
              <span></span><span></span><span></span>
            </button>
          </div>
        </div>
      </header>

      <div className={`mobile-menu${menuOpen ? ' open' : ''}`} id="mobile-menu">
        {LINKS.map((l) => (
          <a key={l.href} href={l.href} data-nav onClick={closeMenu}>{l.label}</a>
        ))}
        <a href="#contact" className="btn btn-primary" onClick={closeMenu}>LET'S TALK</a>
        <div className="mm-contact">
          <a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">WhatsApp</a>
          <a href="mailto:mdsaifislam790@gmail.com" aria-label="Email">Email</a>
        </div>
      </div>
    </>
  );
}
