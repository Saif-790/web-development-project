import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-top">
          <div>
            <div className="footer-brand">MD. SAIF<span>.</span>ISLAM</div>
            <div className="footer-sub">WordPress Web Developer &amp; Web Designer</div>
            <div className="footer-contact">
              <a href="https://wa.me/8801516549964" target="_blank" rel="noopener noreferrer">01516549964</a>
              <a href="mailto:mdsaifislam790@gmail.com">mdsaifislam790@gmail.com</a>
            </div>
          </div>
          <nav className="footer-nav" aria-label="Footer">
            <a href="#work">Work</a><a href="#about">About</a><a href="#services">Services</a>
            <a href="#experience">Experience</a><a href="#contact">Contact</a>
          </nav>
        </div>
        <div className="footer-bottom">
          <span>© 2026 MD. Saif Islam. All rights reserved. — Designed &amp; developed with precision.</span>
          <Link to="/admin/login" className="admin-link" style={{ background: 'none', border: 'none', fontFamily: 'inherit' }}>
            Admin Dashboard
          </Link>
        </div>
      </div>
    </footer>
  );
}
