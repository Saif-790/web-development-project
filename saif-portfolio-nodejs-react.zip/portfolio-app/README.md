# SAIF.DEV Portfolio — Node.js + React

This is your portfolio site converted from a single static HTML file into
two apps:

- **`server/`** — Node.js/Express API (projects, contact messages, admin auth)
- **`client/`** — React app (Vite) — the public site + the admin dashboard

The design (colors, fonts, layout, animations) is the same as your original
file — the CSS was carried over as-is.

## What changed about the admin panel

Your original file had an "Admin Dashboard" button that opened the whole
admin panel to anyone, no password, with all data sitting in the browser's
`localStorage` (visible/editable by anyone with dev tools). That's now
replaced with:

- A real login screen (`/admin/login`)
- The password is never stored in plain text — only a **bcrypt hash**
- Sessions use a signed **JWT in an httpOnly cookie** (JavaScript on the
  page cannot read it, which protects it from XSS)
- Login attempts are **rate-limited** (8 tries per 15 minutes per IP)
- Every admin API route checks the session server-side before doing anything
- Project/message data lives on the server (a JSON file by default — see
  "Going to production" below), not in the visitor's browser

## 1. Setup — Backend

```bash
cd server
npm install
cp .env.example .env
```

Generate your admin password hash (replace the example password):

```bash
npm run hash-password -- "YourStrongPassword123!"
```

Copy the printed `ADMIN_PASSWORD_HASH=...` line into `server/.env`.

Also fill in `server/.env`:
- `ADMIN_USERNAME` — whatever login username you want
- `JWT_SECRET` — a long random string, e.g. generate one with:
  ```bash
  node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
  ```

Start the API:

```bash
npm run dev
```

It runs on `http://localhost:5000` by default.

## 2. Setup — Frontend

```bash
cd client
npm install
cp .env.example .env
npm run dev
```

It runs on `http://localhost:5173` and talks to the API at the URL in
`client/.env` (`VITE_API_URL`).

Visit `http://localhost:5173` for the public site, and
`http://localhost:5173/admin/login` to sign in to the dashboard.

## 3. Build for production

```bash
cd client && npm run build
```

This outputs static files to `client/dist/` — deploy those to any static
host (Vercel, Netlify, etc.) and deploy `server/` to a Node host (Railway,
Render, a VPS, etc.). Set `client/.env`'s `VITE_API_URL` to your deployed
API's URL before building, and set `NODE_ENV=production` plus your real
`CLIENT_ORIGIN` in the server's `.env`.

## Going to production — a few things worth knowing

- **Storage**: `server/db.js` uses a simple JSON file (`server/data/db.json`)
  so the project has zero native dependencies to install. It works fine for
  a personal portfolio, but for anything higher-traffic, swap it for a real
  database (Postgres/MySQL/MongoDB) — every other file only calls
  `readDb()`/`writeDb()`, so that's the only file you'd need to change.
- **Images**: the admin form takes an image *URL* rather than a file
  upload. Wiring up real file uploads (e.g. to S3/Cloudinary) is a
  reasonable next step if you want to upload images directly.
- **Contact form vs. live chat**: the original file's chat widget was a
  simulated/fake bot with no real backend. I replaced it with a real
  contact form that saves messages to the database and shows them in the
  admin "Messages" tab. A true live chat (two people messaging in real
  time) would need WebSockets — a bigger separate feature if you want it.
- **Backups**: since data lives in a file (or DB) on the server now
  instead of each visitor's browser, make sure your host backs up
  `server/data/db.json` (or your database) regularly.
- Never commit `server/.env` or `client/.env` to git — both are already
  covered by `.gitignore`.

## Project structure

```
server/
  server.js            Express app entry
  db.js                 tiny JSON file datastore
  middleware/auth.js    JWT verification for protected routes
  routes/auth.js        login / logout / session check
  routes/projects.js    public + admin project CRUD
  routes/messages.js    contact form + admin inbox
  scripts/hashPassword.js  CLI helper to hash your admin password

client/
  src/
    api.js                    fetch wrapper (sends cookies)
    context/AuthContext.jsx   admin session state
    components/               Navbar, Footer, ProtectedRoute, sections/*
    pages/Home.jsx            public site
    pages/AdminLogin.jsx      login screen
    pages/AdminDashboard.jsx  dashboard, projects, messages, settings
```
