const express = require('express');
const { readDb, writeDb } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function sanitizeProjectInput(body) {
  const clean = {
    title: String(body.title || '').trim().slice(0, 200),
    category: String(body.category || '').trim().slice(0, 60),
    year: String(body.year || '').trim().slice(0, 10),
    image: String(body.image || '').trim().slice(0, 1000),
    description: String(body.description || '').trim().slice(0, 2000),
    url: String(body.url || '').trim().slice(0, 500),
    status: body.status === 'draft' ? 'draft' : 'published',
    technologies: Array.isArray(body.technologies)
      ? body.technologies.map((t) => String(t).trim().slice(0, 60)).filter(Boolean).slice(0, 20)
      : []
  };
  return clean;
}

// GET /api/projects — public, published projects only
router.get('/', (req, res) => {
  const db = readDb();
  const published = db.projects.filter((p) => p.status === 'published');
  res.json(published);
});

// ---- everything below this line requires a valid admin session ----
router.use(requireAuth);

// GET /api/projects/admin/all — every project, drafts included
router.get('/admin/all', (req, res) => {
  const db = readDb();
  res.json(db.projects);
});

// POST /api/projects — create
router.post('/', (req, res) => {
  if (!req.body || !req.body.title || !req.body.category) {
    return res.status(400).json({ error: 'Title and category are required.' });
  }
  const db = readDb();
  const project = {
    id: db.nextProjectId,
    ...sanitizeProjectInput(req.body),
    createdAt: new Date().toISOString()
  };
  db.projects.push(project);
  db.nextProjectId += 1;
  writeDb(db);
  res.status(201).json(project);
});

// PUT /api/projects/:id — update
router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  const db = readDb();
  const idx = db.projects.findIndex((p) => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found.' });

  db.projects[idx] = { ...db.projects[idx], ...sanitizeProjectInput(req.body) };
  writeDb(db);
  res.json(db.projects[idx]);
});

// DELETE /api/projects/:id
router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const db = readDb();
  const exists = db.projects.some((p) => p.id === id);
  if (!exists) return res.status(404).json({ error: 'Project not found.' });

  db.projects = db.projects.filter((p) => p.id !== id);
  writeDb(db);
  res.json({ success: true });
});

module.exports = router;
