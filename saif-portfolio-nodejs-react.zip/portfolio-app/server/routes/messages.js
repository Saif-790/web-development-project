const express = require('express');
const rateLimit = require('express-rate-limit');
const { readDb, writeDb } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many messages sent. Please try again later.' }
});

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// POST /api/messages — public contact form submission
router.post('/', contactLimiter, (req, res) => {
  const { name, email, message } = req.body || {};

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email and message are required.' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  const db = readDb();
  const entry = {
    id: db.nextMessageId,
    name: String(name).trim().slice(0, 120),
    email: String(email).trim().slice(0, 200),
    message: String(message).trim().slice(0, 2000),
    read: false,
    createdAt: new Date().toISOString()
  };
  db.messages.unshift(entry);
  db.nextMessageId += 1;
  writeDb(db);
  res.status(201).json({ success: true });
});

// ---- admin-only below ----
router.use(requireAuth);

router.get('/', (req, res) => {
  const db = readDb();
  res.json(db.messages);
});

router.patch('/:id/read', (req, res) => {
  const id = Number(req.params.id);
  const db = readDb();
  const msg = db.messages.find((m) => m.id === id);
  if (!msg) return res.status(404).json({ error: 'Message not found.' });
  msg.read = true;
  writeDb(db);
  res.json(msg);
});

router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const db = readDb();
  const exists = db.messages.some((m) => m.id === id);
  if (!exists) return res.status(404).json({ error: 'Message not found.' });
  db.messages = db.messages.filter((m) => m.id !== id);
  writeDb(db);
  res.json({ success: true });
});

module.exports = router;
