const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Brute-force protection: only 8 login attempts per IP every 15 minutes.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});

function cookieOptions() {
  const isProd = process.env.NODE_ENV === 'production';
  return {
    httpOnly: true,           // JS on the page can never read this cookie
    secure: isProd,           // HTTPS only in production
    sameSite: isProd ? 'strict' : 'lax',
    maxAge: 2 * 60 * 60 * 1000, // 2 hours
    path: '/'
  };
}

// POST /api/auth/login
router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const validUsername = username === process.env.ADMIN_USERNAME;
  // Always run bcrypt.compare, even on an unknown username, so that
  // response timing doesn't leak whether the username was correct.
  const hashToCheck = process.env.ADMIN_PASSWORD_HASH || '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinva';
  const validPassword = await bcrypt.compare(password, hashToCheck);

  if (!validUsername || !validPassword) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  const token = jwt.sign(
    { username },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '2h' }
  );

  res.cookie('token', token, cookieOptions());
  res.json({ success: true, username });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('token', { path: '/' });
  res.json({ success: true });
});

// GET /api/auth/me  — used by the React app to check session status on load
router.get('/me', requireAuth, (req, res) => {
  res.json({ authenticated: true, username: req.admin.username });
});

module.exports = router;
