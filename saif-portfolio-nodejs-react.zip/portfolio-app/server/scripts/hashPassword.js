/**
 * Helper script: generates a bcrypt hash for the admin password so you
 * never have to store a plain-text password anywhere.
 *
 * Usage:
 *   npm run hash-password -- "YourStrongPassword123!"
 *
 * Copy the printed hash into server/.env as ADMIN_PASSWORD_HASH.
 */
const bcrypt = require('bcryptjs');

const password = process.argv[2];

if (!password) {
  console.error('Usage: npm run hash-password -- "YourStrongPassword123!"');
  process.exit(1);
}

if (password.length < 8) {
  console.warn('Warning: that password is quite short. Use at least 12+ characters, mixing letters, numbers and symbols.');
}

const hash = bcrypt.hashSync(password, 12);
console.log('\nAdd this line to server/.env :\n');
console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);
