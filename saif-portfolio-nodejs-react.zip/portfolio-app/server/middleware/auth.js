const jwt = require('jsonwebtoken');

/**
 * Protects admin-only routes.
 * Reads the JWT from the httpOnly "token" cookie (never from
 * localStorage/sessionStorage — that would be readable by any XSS
 * payload, which defeats the point of the token).
 */
function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.token;

  if (!token) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.admin = { username: payload.username };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
}

module.exports = { requireAuth };
