/**
 * Very small file-based JSON datastore.
 *
 * This is intentionally simple so the project has zero native
 * dependencies to compile. For a real production deployment, swap
 * this module out for Postgres/MySQL/MongoDB — the rest of the app
 * only talks to the functions exported here, so nothing else needs
 * to change.
 */
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'data', 'db.json');

function seedProjects() {
  return [
    { id: 1, title: 'Business Website', category: 'business', year: '2026',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=60',
      description: 'A modern business website designed to establish a strong digital presence and convert visitors into customers.',
      technologies: ['WordPress', 'Elementor', 'CSS'], url: '', status: 'published', createdAt: '2026-01-05T09:00:00.000Z' },
    { id: 2, title: 'Ecommerce Store', category: 'ecommerce', year: '2026',
      image: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&w=1200&q=60',
      description: 'A conversion-focused online store with a clean shopping experience and optimized product presentation.',
      technologies: ['WordPress', 'WooCommerce', 'Elementor'], url: '', status: 'published', createdAt: '2026-02-10T09:00:00.000Z' },
    { id: 3, title: 'Creative Agency Website', category: 'agency', year: '2026',
      image: 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&w=1200&q=60',
      description: 'A premium agency website with a strong visual identity, modern interactions and professional content structure.',
      technologies: ['WordPress', 'Elementor', 'Custom CSS'], url: '', status: 'published', createdAt: '2026-03-18T09:00:00.000Z' },
    { id: 4, title: 'Landing Page', category: 'landing-page', year: '2026',
      image: 'https://images.unsplash.com/photo-1487014679447-9f8336841d58?auto=format&fit=crop&w=1200&q=60',
      description: 'A high-converting landing page designed to communicate the offer clearly and guide visitors toward action.',
      technologies: ['WordPress', 'Elementor', 'CSS'], url: '', status: 'published', createdAt: '2026-04-22T09:00:00.000Z' },
    { id: 5, title: 'Personal Brand Website', category: 'portfolio', year: '2026',
      image: 'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=1200&q=60',
      description: 'A modern personal brand website designed to showcase expertise, services, projects and credibility.',
      technologies: ['WordPress', 'Elementor', 'Custom Design'], url: '', status: 'published', createdAt: '2026-05-30T09:00:00.000Z' }
  ];
}

function defaultData() {
  return { projects: seedProjects(), messages: [], nextProjectId: 6, nextMessageId: 1 };
}

function ensureDbFile() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData(), null, 2));
  }
}

function readDb() {
  ensureDbFile();
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('db.json was corrupted, resetting to defaults:', e.message);
    const fresh = defaultData();
    writeDb(fresh);
    return fresh;
  }
}

function writeDb(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

module.exports = { readDb, writeDb };
